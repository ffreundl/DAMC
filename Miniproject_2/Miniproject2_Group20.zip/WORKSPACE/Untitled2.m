figure
histogram(features(classZeroPositions,528),'Normalization','probability');
hold on
histogram(features(classOnePositions,528),'Normalization','probability')
