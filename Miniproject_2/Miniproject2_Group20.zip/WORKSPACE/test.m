cd=cvpartition(labels,'kfold',10);

cd_new=repartition(cd);



